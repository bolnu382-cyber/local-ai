package app.composer

import kotlin.random.Random

/**
 * Составитель текста. Нейросеть не используется: предложения собираются по частотам
 * сочетаний слов (триграммы) из загруженных источников, вперёд и назад от слова по теме.
 * Предложения с совпадением 7 слов подряд с источником отбрасываются.
 */
class Composer(private val store: Store) {

    private val rnd = Random(System.nanoTime())

    private val stop = setOf(
        "этого", "этот", "этой", "этих", "этом", "который", "которая", "которые", "которого",
        "когда", "чтобы", "также", "более", "очень", "после", "через", "между", "было", "были",
        "будет", "быть", "есть", "если", "только", "можно", "нужно", "своей", "свои", "свой",
        "тоже", "where", "which", "there", "their", "about", "would", "could", "should",
        "these", "those", "with", "from", "have", "that", "this"
    )

    /** Составляет count предложений по теме; context — текст пользователя, к которому идёт продолжение. */
    fun compose(topic: String, count: Int, context: String = ""): List<String> {
        val keys = keywords("$topic $context")
        val seedCache = HashMap<String, List<Triple<String, String, Int>>>()
        val used = HashSet<Long>()
        val out = ArrayList<String>()
        var pool = keys
        for (slot in 0 until count) {
            var best: List<String>? = null
            var bestScore = -1
            var found = 0
            var tries = 0
            while (tries < 40 && found < 6) {
                tries++
                val useSeed = pool.isNotEmpty() && (slot == 0 || rnd.nextInt(100) < 70)
                val seed = if (useSeed) pickSeed(pool, seedCache) else null
                val toks = build(seed)
                if (!valid(toks, used)) continue
                found++
                val sc = score(toks, pool)
                if (sc > bestScore) {
                    best = toks
                    bestScore = sc
                }
            }
            val chosen = best ?: continue
            used.add(Tokenizer.hash(lowerWords(chosen)))
            out.add(detok(chosen))
            pool = nextPool(keys, chosen)
        }
        return out
    }

    // ---------- ключевые слова ----------

    private fun stem(w: String): String = if (w.length <= 5) w else w.substring(0, w.length - 2)

    private fun keywords(text: String): List<String> {
        val seen = LinkedHashSet<String>()
        for (m in Regex("\\p{L}+").findAll(text)) {
            val w = m.value.lowercase()
            if (w.length >= 4 && w !in stop) seen.add(stem(w))
        }
        return seen.toList().takeLast(12)
    }

    private fun nextPool(keys: List<String>, toks: List<String>): List<String> {
        val extra = lowerWords(toks).filter { it.length >= 6 && it !in stop }.distinct().shuffled(rnd).take(2)
            .map { stem(it) }
        return (keys.takeLast(6) + extra).distinct()
    }

    private fun score(toks: List<String>, pool: List<String>): Int {
        val words = lowerWords(toks)
        var n = 0
        for (s in pool) if (words.any { it.startsWith(s) }) n++
        return n
    }

    private fun lowerWords(t: List<String>): List<String> =
        t.filter { Tokenizer.isWord(it) }.map { it.lowercase() }

    // ---------- выбор начальной пары ----------

    private fun pickSeed(
        pool: List<String>,
        cache: HashMap<String, List<Triple<String, String, Int>>>
    ): Pair<String, String>? {
        val stem = pool[rnd.nextInt(pool.size)]
        val states = cache.getOrPut(stem) {
            val forms = store.findWords(stem, 6)
            if (forms.isEmpty()) emptyList() else store.seedStates(forms, 15)
        }
        if (states.isEmpty()) return null
        val pick = weighted(states.map { "${it.first}\u0000${it.second}" to it.third })
        val i = pick.indexOf('\u0000')
        return pick.substring(0, i) to pick.substring(i + 1)
    }

    private fun weighted(items: List<Pair<String, Int>>): String {
        var total = 0L
        for (it in items) total += it.second
        var r = (rnd.nextDouble() * total).toLong()
        for (it in items) {
            r -= it.second
            if (r < 0) return it.first
        }
        return items.last().first
    }

    // ---------- построение предложения ----------

    /** Следующий токен. Если продолжение по трём словам единственное и повторяется подряд,
     *  берётся продолжение по двум словам, чтобы не воспроизводить источник целиком. */
    private fun pickNext(dir: Int, x: String, y: String, run: Int): Pair<String, Int>? {
        val tri = store.next(dir, x, y)
        if (tri.isNotEmpty() && !(tri.size == 1 && run >= 3)) {
            return weighted(tri) to (if (tri.size == 1) run + 1 else 0)
        }
        val bi = store.next(dir, "*", y)
        val banned = tri.map { it.first }.toSet()
        val alt = bi.filter { it.first !in banned }
        val src = if (alt.isNotEmpty()) alt else if (tri.isNotEmpty()) tri else bi
        if (src.isEmpty()) return null
        return weighted(src) to 0
    }

    private fun build(seed: Pair<String, String>?): List<String> {
        val tokens = ArrayList<String>()
        var x: String
        var y: String
        if (seed == null) {
            x = Tokenizer.BOS
            y = Tokenizer.BOS
        } else {
            x = seed.first
            y = seed.second
            tokens.add(x)
            tokens.add(y)
        }
        var run = 0
        while (tokens.size < 60) {
            val step = pickNext(0, x, y, run) ?: break
            run = step.second
            if (step.first == Tokenizer.EOS) break
            tokens.add(step.first)
            x = y
            y = step.first
        }
        if (seed != null && seed.first != Tokenizer.BOS) {
            var bx = seed.second
            var by = seed.first
            var reached = false
            val head = ArrayList<String>()
            run = 0
            while (head.size < 60) {
                val step = pickNext(1, bx, by, run) ?: break
                run = step.second
                if (step.first == Tokenizer.BOS) {
                    reached = true
                    break
                }
                head.add(step.first)
                bx = by
                by = step.first
            }
            if (!reached) return emptyList()
            head.reverse()
            tokens.addAll(0, head)
        }
        tokens.removeAll { it == Tokenizer.BOS || it == Tokenizer.EOS }
        if (tokens.isNotEmpty() && !Tokenizer.isEnd(tokens.last())) tokens.add(".")
        return tokens
    }

    private fun valid(toks: List<String>, used: Set<Long>): Boolean {
        if (toks.isEmpty()) return false
        val words = lowerWords(toks)
        if (words.size < 5 || words.size > 32) return false
        if (!Tokenizer.isEnd(toks.last())) return false
        if (toks.count { it == "," } > 6) return false
        for (i in 2 until words.size) {
            if (words[i] == words[i - 1] && words[i] == words[i - 2]) return false
        }
        for (i in 1 until toks.size) {
            if (!Tokenizer.isWord(toks[i]) && !Tokenizer.isWord(toks[i - 1])) return false
        }
        if (Tokenizer.hash(words) in used) return false
        return Tokenizer.shingles(words).none { store.hasShingle(it) }
    }

    private fun detok(toks: List<String>): String {
        val sb = StringBuilder()
        for (t in toks) {
            if (Tokenizer.isWord(t)) {
                if (sb.isNotEmpty()) sb.append(' ')
            }
            sb.append(t)
        }
        if (sb.isNotEmpty()) sb.setCharAt(0, sb[0].uppercaseChar())
        return sb.toString()
    }
}
