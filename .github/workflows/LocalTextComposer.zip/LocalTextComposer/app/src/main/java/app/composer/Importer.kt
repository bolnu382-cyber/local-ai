package app.composer

import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.Charset

/** Загрузка источников: сайты, сохранённые страницы, текстовые файлы, словари. */
object Importer {

    private val skipExt = Regex(
        ".*\\.(jpe?g|png|gif|webp|svg|ico|pdf|zip|rar|7z|mp3|mp4|avi|mkv|css|js|json|xml|apk|exe|docx?|xlsx?)(\\?.*)?$",
        RegexOption.IGNORE_CASE
    )
    private val hrefRe = Regex("href\\s*=\\s*[\"']([^\"'#]+)[\"']", RegexOption.IGNORE_CASE)
    private val metaCharset = Regex("charset\\s*=\\s*[\"']?([\\w-]+)", RegexOption.IGNORE_CASE)

    // ---------- сайты ----------

    /** Обходит страницы одного сайта (ширина обхода — maxPages) и возвращает html страниц. */
    fun crawl(startUrl: String, maxPages: Int, progress: (Int, String) -> Unit): List<String> {
        val start = if (startUrl.startsWith("http", true)) startUrl else "https://$startUrl"
        val host = URL(start).host
        val queue = ArrayDeque<String>()
        val seen = HashSet<String>()
        val pages = ArrayList<String>()
        queue.add(start)
        seen.add(start)
        while (queue.isNotEmpty() && pages.size < maxPages) {
            val url = queue.removeFirst()
            val html = try {
                download(url)
            } catch (e: Exception) {
                null
            } ?: continue
            pages.add(html)
            progress(pages.size, url)
            for (m in hrefRe.findAll(html)) {
                val link = try {
                    URL(URL(url), m.groupValues[1].trim()).toString()
                } catch (e: Exception) {
                    continue
                }
                if (!link.startsWith("http", true)) continue
                if (URL(link).host != host) continue
                if (skipExt.matches(link)) continue
                if (seen.add(link)) queue.add(link)
            }
            Thread.sleep(300)
        }
        return pages
    }

    private fun download(url: String): String? {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 20000
        c.setRequestProperty("User-Agent", "LocalTextComposer/1.0")
        c.setRequestProperty("Accept", "text/html,text/plain")
        try {
            if (c.responseCode !in 200..299) return null
            val type = c.contentType ?: ""
            if (type.isNotEmpty() && !type.contains("text", true) && !type.contains("html", true)) return null
            val bytes = c.inputStream.use { readLimited(it, 3_000_000) }
            var name = metaCharset.find(type)?.groupValues?.get(1)
            if (name == null) {
                val head = String(bytes, 0, minOf(bytes.size, 3000), Charsets.ISO_8859_1)
                name = metaCharset.find(head)?.groupValues?.get(1)
            }
            val cs = try {
                if (name != null) Charset.forName(name) else Charsets.UTF_8
            } catch (e: Exception) {
                Charsets.UTF_8
            }
            return String(bytes, cs)
        } finally {
            c.disconnect()
        }
    }

    fun readLimited(input: InputStream, limit: Int): ByteArray {
        val out = java.io.ByteArrayOutputStream()
        val buf = ByteArray(16384)
        var total = 0
        while (true) {
            val n = input.read(buf)
            if (n < 0) break
            total += n
            if (total > limit) break
            out.write(buf, 0, n)
        }
        return out.toByteArray()
    }

    // ---------- разбор html ----------

    fun htmlToText(html: String): String {
        var s = html
        s = Regex("(?is)<(script|style|noscript|svg|head|nav|footer|form)\\b.*?</\\1>").replace(s, " ")
        s = Regex("(?is)<!--.*?-->").replace(s, " ")
        s = Regex("(?i)</?(p|div|br|li|ul|ol|h[1-6]|tr|td|th|table|section|article|header|blockquote)\\b[^>]*>")
            .replace(s, "\n")
        s = Regex("(?s)<[^>]*>").replace(s, " ")
        s = decodeEntities(s)
        val lines = s.split('\n')
            .map { it.replace(Regex("[ \\t\\u00A0]+"), " ").trim() }
            .filter { line -> line.count { it == ' ' } >= 4 }
        return lines.joinToString("\n")
    }

    private fun decodeEntities(text: String): String {
        var s = text
            .replace("&nbsp;", " ").replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
            .replace("&quot;", "\"").replace("&#39;", "'").replace("&laquo;", "«").replace("&raquo;", "»")
            .replace("&mdash;", "—").replace("&ndash;", "–").replace("&hellip;", "…")
        s = Regex("&#(\\d+);").replace(s) {
            val code = it.groupValues[1].toIntOrNull()
            if (code != null && code in 32..0x10FFFF) String(Character.toChars(code)) else " "
        }
        s = Regex("&#x([0-9a-fA-F]+);").replace(s) {
            val code = it.groupValues[1].toIntOrNull(16)
            if (code != null && code in 32..0x10FFFF) String(Character.toChars(code)) else " "
        }
        return s
    }

    // ---------- загрузка в хранилище ----------

    /** Текст (в том числе очищенный от разметки сайт): предложения и словоформы. Возвращает число предложений. */
    fun importText(store: Store, kind: String, name: String, texts: List<String>): Int {
        val sentences = ArrayList<List<String>>()
        for (t in texts) sentences.addAll(Tokenizer.sentences(t))
        if (sentences.isEmpty()) return 0
        val id = store.createSource(kind, name)
        ingest(store, id, sentences)
        return sentences.size
    }

    /**
     * Словарь: столбец слов (опционально со столбцом частот). Строки из нескольких слов
     * считаются фразами и дополнительно идут в предложения. Возвращает число слов словаря.
     */
    fun importDictionary(store: Store, name: String, text: String): Int {
        val words = HashMap<Pair<String, String>, Int>()
        val prose = StringBuilder()
        for (raw in text.split('\n')) {
            val line = raw.trim()
            if (line.isEmpty()) continue
            val parts = line.split(Regex("[\\t;|]+|\\s{2,}")).map { it.trim() }.filter { it.isNotEmpty() }
            val wordTokens = Regex("[\\p{L}][\\p{L}\\p{N}'’-]*").findAll(line).map { it.value }.toList()
            if (wordTokens.size > 3) {
                prose.append(line).append('\n')
                continue
            }
            val head = parts.firstOrNull() ?: continue
            val hw = Regex("^[\\p{L}][\\p{L}\\p{N}'’-]*").find(head)?.value ?: continue
            val freq = parts.getOrNull(1)?.toIntOrNull() ?: 1
            val lw = hw.lowercase()
            val key = lw to lw
            words[key] = (words[key] ?: 0) + maxOf(1, freq)
        }
        if (words.isEmpty() && prose.isEmpty()) return 0
        val id = store.createSource("dictionary", name)
        if (words.isNotEmpty()) {
            store.addCounts(id, emptyMap(), words, emptySet(), 0, words.size)
        }
        if (prose.isNotEmpty()) {
            ingest(store, id, Tokenizer.sentences(prose.toString()))
        }
        return words.size
    }

    private fun inc(m: HashMap<NgKey, Int>, k: NgKey) {
        m[k] = (m[k] ?: 0) + 1
    }

    fun ingest(store: Store, src: Long, sentences: List<List<String>>) {
        for (chunk in sentences.chunked(3000)) {
            val ng = HashMap<NgKey, Int>()
            val words = HashMap<Pair<String, String>, Int>()
            val sh = HashSet<Long>()
            var wordCount = 0
            for (s in chunk) {
                val p = ArrayList<String>(s.size + 3)
                p.add(Tokenizer.BOS)
                p.add(Tokenizer.BOS)
                p.addAll(s)
                p.add(Tokenizer.EOS)
                for (i in 0..p.size - 3) {
                    inc(ng, NgKey(0, p[i], p[i + 1], p[i + 2]))
                    inc(ng, NgKey(0, "*", p[i + 1], p[i + 2]))
                }
                val r = p.reversed()
                for (i in 0..r.size - 3) {
                    inc(ng, NgKey(1, r[i], r[i + 1], r[i + 2]))
                    inc(ng, NgKey(1, "*", r[i + 1], r[i + 2]))
                }
                val lower = ArrayList<String>()
                for (t in s) {
                    if (!Tokenizer.isWord(t)) continue
                    val lw = t.lowercase()
                    lower.add(lw)
                    val k = lw to t
                    words[k] = (words[k] ?: 0) + 1
                    wordCount++
                }
                sh.addAll(Tokenizer.shingles(lower))
            }
            store.addCounts(src, ng, words, sh, chunk.size, wordCount)
        }
    }
}
