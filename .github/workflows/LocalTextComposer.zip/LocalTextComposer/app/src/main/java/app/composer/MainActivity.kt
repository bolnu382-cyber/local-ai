package app.composer

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.text.InputType
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private lateinit var store: Store
    private lateinit var composer: Composer
    private lateinit var status: TextView
    private lateinit var input: EditText
    private lateinit var countField: EditText
    private lateinit var output: TextView

    private val worker = Executors.newSingleThreadExecutor()
    private var pendingKind = "text"
    private val requestFile = 11

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        composer = Composer(store)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(16), dp(16), dp(16))

        root.addView(label("Локальный генератор текста", 22f, true))
        status = label("", 14f, false)
        root.addView(status)

        root.addView(button("Добавить сайт") { askSite() })
        root.addView(button("Добавить файл или словарь") { askFileKind() })
        root.addView(button("Источники") { showSources() })
        root.addView(button("Очистить хранилище") { askClear() })

        root.addView(label("Тема или ваш текст", 16f, true))
        input = EditText(this)
        input.minLines = 4
        input.gravity = android.view.Gravity.TOP
        input.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        root.addView(input, matchWrap())

        root.addView(label("Число предложений (1–30)", 14f, false))
        countField = EditText(this)
        countField.inputType = InputType.TYPE_CLASS_NUMBER
        countField.setText("6")
        root.addView(countField, matchWrap())

        root.addView(button("Составить текст по теме") { runCompose(false) })
        root.addView(button("Дополнить мой текст") { runCompose(true) })

        output = label("", 16f, false)
        output.setTextIsSelectable(true)
        root.addView(output)
        root.addView(button("Копировать результат") { copyOutput() })

        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
        refreshStatus()
    }

    // ---------- интерфейс ----------

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun label(text: String, size: Float, bold: Boolean): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = size
        if (bold) t.setTypeface(t.typeface, android.graphics.Typeface.BOLD)
        t.setPadding(0, dp(8), 0, dp(4))
        return t
    }

    private fun button(text: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.setOnClickListener { onClick() }
        return b
    }

    private fun ui(block: () -> Unit) {
        runOnUiThread { block() }
    }

    private fun refreshStatus() {
        worker.execute {
            val list = store.sources()
            val sentences = list.sumOf { it.sentences }
            val sites = list.count { it.kind == "site" }
            val dicts = list.count { it.kind == "dictionary" }
            val files = list.count { it.kind == "text" }
            val s = if (list.isEmpty()) {
                "Хранилище пусто. Добавьте сайт, файл или словарь."
            } else {
                "Источников: ${list.size} (сайтов $sites, файлов $files, словарей $dicts). Предложений в базе: $sentences."
            }
            ui { status.text = s }
        }
    }

    private fun toast(text: String) = ui { Toast.makeText(this, text, Toast.LENGTH_LONG).show() }

    // ---------- сайт ----------

    private fun askSite() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(8), dp(16), 0)
        val url = EditText(this)
        url.hint = "Адрес сайта"
        url.inputType = InputType.TYPE_TEXT_VARIATION_URI
        val pages = EditText(this)
        pages.hint = "Сколько страниц загрузить (1–300)"
        pages.inputType = InputType.TYPE_CLASS_NUMBER
        pages.setText("30")
        box.addView(url)
        box.addView(pages)
        AlertDialog.Builder(this)
            .setTitle("Добавить сайт")
            .setMessage("Страницы загружаются один раз. После загрузки сайт хранится на устройстве, и составление текста работает без сети.")
            .setView(box)
            .setPositiveButton("Загрузить") { _, _ ->
                val u = url.text.toString().trim()
                val n = (pages.text.toString().toIntOrNull() ?: 30).coerceIn(1, 300)
                if (u.isNotEmpty()) loadSite(u, n)
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun loadSite(url: String, maxPages: Int) {
        worker.execute {
            try {
                ui { status.text = "Загрузка страниц..." }
                val pages = Importer.crawl(url, maxPages) { done, _ ->
                    ui { status.text = "Загружено страниц: $done" }
                }
                if (pages.isEmpty()) {
                    toast("Страницы не загружены. Проверьте адрес и подключение.")
                } else {
                    ui { status.text = "Обработка текста..." }
                    val texts = pages.map { Importer.htmlToText(it) }
                    val n = Importer.importText(store, "site", url, texts)
                    toast(if (n == 0) "На страницах не найдено текста." else "Добавлено предложений: $n")
                }
            } catch (e: Exception) {
                toast("Ошибка загрузки: ${e.message}")
            }
            refreshStatus()
        }
    }

    // ---------- файлы и словари ----------

    private fun askFileKind() {
        AlertDialog.Builder(this)
            .setTitle("Что добавляется")
            .setItems(arrayOf("Словарь (список слов)", "Текст или сохранённая страница (txt, html)")) { _, which ->
                pendingKind = if (which == 0) "dictionary" else "text"
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
                i.addCategory(Intent.CATEGORY_OPENABLE)
                i.type = "*/*"
                startActivityForResult(i, requestFile)
            }
            .show()
    }

    @Deprecated("Используется без дополнительных библиотек")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != requestFile || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        val kind = pendingKind
        worker.execute {
            try {
                ui { status.text = "Чтение файла..." }
                val name = displayName(uri)
                val bytes = contentResolver.openInputStream(uri)?.use { Importer.readLimited(it, 50_000_000) }
                if (bytes == null) {
                    toast("Файл не открылся.")
                } else {
                    var text = String(bytes, Charsets.UTF_8)
                    val n: Int
                    if (kind == "dictionary") {
                        n = Importer.importDictionary(store, name, text)
                        toast(if (n == 0) "В файле не найдено слов." else "Добавлено слов: $n")
                    } else {
                        val isHtml = name.endsWith(".html", true) || name.endsWith(".htm", true) ||
                            text.take(2000).contains("<html", true)
                        if (isHtml) text = Importer.htmlToText(text)
                        n = Importer.importText(store, "text", name, listOf(text))
                        toast(if (n == 0) "В файле не найдено предложений." else "Добавлено предложений: $n")
                    }
                }
            } catch (e: Exception) {
                toast("Ошибка чтения: ${e.message}")
            }
            refreshStatus()
        }
    }

    private fun displayName(uri: Uri): String {
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && c.moveToFirst()) return c.getString(i)
        }
        return uri.lastPathSegment ?: "файл"
    }

    // ---------- источники ----------

    private fun showSources() {
        worker.execute {
            val list = store.sources()
            ui {
                if (list.isEmpty()) {
                    Toast.makeText(this, "Источников нет.", Toast.LENGTH_SHORT).show()
                } else {
                    val names = list.map { "${kindName(it.kind)}: ${it.name} (${it.sentences} предложений, ${it.words} слов)" }
                    AlertDialog.Builder(this)
                        .setTitle("Источники (нажмите, чтобы удалить)")
                        .setItems(names.toTypedArray()) { _, which -> askDelete(list[which]) }
                        .setNegativeButton("Закрыть", null)
                        .show()
                }
            }
        }
    }

    private fun kindName(kind: String) = when (kind) {
        "site" -> "Сайт"
        "dictionary" -> "Словарь"
        else -> "Файл"
    }

    private fun askDelete(s: SourceInfo) {
        AlertDialog.Builder(this)
            .setTitle("Удалить источник?")
            .setMessage(s.name)
            .setPositiveButton("Удалить") { _, _ ->
                worker.execute {
                    store.deleteSource(s.id)
                    refreshStatus()
                }
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun askClear() {
        AlertDialog.Builder(this)
            .setTitle("Очистить хранилище?")
            .setMessage("Все загруженные источники будут удалены с устройства.")
            .setPositiveButton("Очистить") { _, _ ->
                worker.execute {
                    store.clearAll()
                    refreshStatus()
                    ui { output.text = "" }
                }
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    // ---------- составление ----------

    private fun runCompose(continueUser: Boolean) {
        val text = input.text.toString().trim()
        val n = (countField.text.toString().toIntOrNull() ?: 6).coerceIn(1, 30)
        if (continueUser && text.isEmpty()) {
            Toast.makeText(this, "Введите свой текст.", Toast.LENGTH_SHORT).show()
            return
        }
        ui { output.text = "Составление текста..." }
        worker.execute {
            val sentences = if (continueUser) {
                composer.compose("", n, text.takeLast(400))
            } else {
                composer.compose(text, n)
            }
            val result = if (sentences.isEmpty()) {
                if (store.sources().isEmpty()) "Сначала добавьте источник."
                else "Не удалось составить предложения. Добавьте больше материала или измените тему."
            } else {
                val body = sentences.chunked(4).joinToString("\n\n") { it.joinToString(" ") }
                if (continueUser) text + "\n\n" + body else body
            }
            ui { output.text = result }
        }
    }

    private fun copyOutput() {
        val t = output.text.toString()
        if (t.isEmpty()) return
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("text", t))
        Toast.makeText(this, "Скопировано", Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        super.onDestroy()
        worker.shutdown()
    }
}
