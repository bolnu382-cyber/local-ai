package app.composer

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class SourceInfo(
    val id: Long,
    val kind: String,
    val name: String,
    val sentences: Int,
    val words: Int
)

data class NgKey(val dir: Int, val w1: String, val w2: String, val nxt: String)

/** Локальное хранилище на устройстве: источники, триграммы, словоформы, хэши для проверки копирования. */
class Store(context: Context) : SQLiteOpenHelper(context, "composer.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE source(id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL, " +
                "name TEXT NOT NULL UNIQUE, added INTEGER NOT NULL, " +
                "sentences INTEGER NOT NULL DEFAULT 0, words INTEGER NOT NULL DEFAULT 0)"
        )
        db.execSQL(
            "CREATE TABLE ng(dir INTEGER NOT NULL, w1 TEXT NOT NULL, w2 TEXT NOT NULL, " +
                "nxt TEXT NOT NULL, src INTEGER NOT NULL, cnt INTEGER NOT NULL, " +
                "PRIMARY KEY(dir, w1, w2, nxt, src)) WITHOUT ROWID"
        )
        db.execSQL("CREATE INDEX ng_w2 ON ng(dir, w2)")
        db.execSQL(
            "CREATE TABLE word(lw TEXT NOT NULL, w TEXT NOT NULL, src INTEGER NOT NULL, " +
                "cnt INTEGER NOT NULL, PRIMARY KEY(lw, w, src)) WITHOUT ROWID"
        )
        db.execSQL(
            "CREATE TABLE shingle(h INTEGER NOT NULL, src INTEGER NOT NULL, " +
                "PRIMARY KEY(h, src)) WITHOUT ROWID"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    /** Создаёт источник; источник с тем же именем заменяется. */
    fun createSource(kind: String, name: String): Long {
        val db = writableDatabase
        db.beginTransaction()
        try {
            val old = ArrayList<Long>()
            db.rawQuery("SELECT id FROM source WHERE name=?", arrayOf(name)).use { c ->
                while (c.moveToNext()) old.add(c.getLong(0))
            }
            for (oldId in old) removeSourceData(db, oldId)
            val cv = ContentValues()
            cv.put("kind", kind)
            cv.put("name", name)
            cv.put("added", System.currentTimeMillis())
            val id = db.insert("source", null, cv)
            db.setTransactionSuccessful()
            return id
        } finally {
            db.endTransaction()
        }
    }

    private fun removeSourceData(db: SQLiteDatabase, id: Long) {
        val a = arrayOf(id.toString())
        db.delete("ng", "src=?", a)
        db.delete("word", "src=?", a)
        db.delete("shingle", "src=?", a)
        db.delete("source", "id=?", a)
    }

    fun deleteSource(id: Long) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            removeSourceData(db, id)
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    fun clearAll() {
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.delete("ng", null, null)
            db.delete("word", null, null)
            db.delete("shingle", null, null)
            db.delete("source", null, null)
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
        db.execSQL("VACUUM")
    }

    fun sources(): List<SourceInfo> {
        val r = ArrayList<SourceInfo>()
        readableDatabase.rawQuery(
            "SELECT id, kind, name, sentences, words FROM source ORDER BY id", null
        ).use { c ->
            while (c.moveToNext()) {
                r.add(SourceInfo(c.getLong(0), c.getString(1), c.getString(2), c.getInt(3), c.getInt(4)))
            }
        }
        return r
    }

    /** Добавляет счётчики порциями: сначала обновление, при отсутствии строки — вставка. */
    fun addCounts(
        src: Long,
        ng: Map<NgKey, Int>,
        words: Map<Pair<String, String>, Int>,
        shingles: Set<Long>,
        sentenceCount: Int,
        wordCount: Int
    ) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            val upNg = db.compileStatement(
                "UPDATE ng SET cnt=cnt+? WHERE dir=? AND w1=? AND w2=? AND nxt=? AND src=?"
            )
            val inNg = db.compileStatement("INSERT INTO ng(dir,w1,w2,nxt,src,cnt) VALUES(?,?,?,?,?,?)")
            for ((k, v) in ng) {
                upNg.clearBindings()
                upNg.bindLong(1, v.toLong())
                upNg.bindLong(2, k.dir.toLong())
                upNg.bindString(3, k.w1)
                upNg.bindString(4, k.w2)
                upNg.bindString(5, k.nxt)
                upNg.bindLong(6, src)
                if (upNg.executeUpdateDelete() == 0) {
                    inNg.clearBindings()
                    inNg.bindLong(1, k.dir.toLong())
                    inNg.bindString(2, k.w1)
                    inNg.bindString(3, k.w2)
                    inNg.bindString(4, k.nxt)
                    inNg.bindLong(5, src)
                    inNg.bindLong(6, v.toLong())
                    inNg.executeInsert()
                }
            }

            val upW = db.compileStatement("UPDATE word SET cnt=cnt+? WHERE lw=? AND w=? AND src=?")
            val inW = db.compileStatement("INSERT INTO word(lw,w,src,cnt) VALUES(?,?,?,?)")
            for ((k, v) in words) {
                upW.clearBindings()
                upW.bindLong(1, v.toLong())
                upW.bindString(2, k.first)
                upW.bindString(3, k.second)
                upW.bindLong(4, src)
                if (upW.executeUpdateDelete() == 0) {
                    inW.clearBindings()
                    inW.bindString(1, k.first)
                    inW.bindString(2, k.second)
                    inW.bindLong(3, src)
                    inW.bindLong(4, v.toLong())
                    inW.executeInsert()
                }
            }

            val inS = db.compileStatement("INSERT OR IGNORE INTO shingle(h,src) VALUES(?,?)")
            for (h in shingles) {
                inS.clearBindings()
                inS.bindLong(1, h)
                inS.bindLong(2, src)
                inS.executeInsert()
            }

            db.execSQL(
                "UPDATE source SET sentences=sentences+?, words=words+? WHERE id=?",
                arrayOf<Any>(sentenceCount, wordCount, src)
            )
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    /** Следующие токены после пары (w1, w2) с суммарными частотами. */
    fun next(dir: Int, w1: String, w2: String): List<Pair<String, Int>> {
        val r = ArrayList<Pair<String, Int>>()
        readableDatabase.rawQuery(
            "SELECT nxt, SUM(cnt) FROM ng WHERE dir=? AND w1=? AND w2=? GROUP BY nxt",
            arrayOf(dir.toString(), w1, w2)
        ).use { c ->
            while (c.moveToNext()) r.add(c.getString(0) to c.getInt(1))
        }
        return r
    }

    /** Формы слов, начинающиеся с основы (как в тексте, с исходным регистром). */
    fun findWords(stem: String, limit: Int): List<String> {
        val r = ArrayList<String>()
        readableDatabase.rawQuery(
            "SELECT w, SUM(cnt) AS c FROM word WHERE lw LIKE ? GROUP BY w ORDER BY c DESC LIMIT ?",
            arrayOf("$stem%", limit.toString())
        ).use { c ->
            while (c.moveToNext()) r.add(c.getString(0))
        }
        return r
    }

    /** Пары слов из источников, содержащие одну из указанных форм. */
    fun seedStates(forms: List<String>, perForm: Int): List<Triple<String, String, Int>> {
        val r = ArrayList<Triple<String, String, Int>>()
        for (f in forms) {
            readableDatabase.rawQuery(
                "SELECT w1, w2, SUM(cnt) FROM ng WHERE dir=0 AND w1<>'*' AND (w1=? OR w2=?) " +
                    "GROUP BY w1, w2 ORDER BY RANDOM() LIMIT ?",
                arrayOf(f, f, perForm.toString())
            ).use { c ->
                while (c.moveToNext()) r.add(Triple(c.getString(0), c.getString(1), c.getInt(2)))
            }
        }
        return r
    }

    fun hasShingle(h: Long): Boolean {
        return readableDatabase.rawQuery(
            "SELECT 1 FROM shingle WHERE h=? LIMIT 1", arrayOf(h.toString())
        ).use { it.moveToFirst() }
    }
}
