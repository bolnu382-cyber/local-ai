package app.composer

/** Разбор текста на предложения и токены, хэши для проверки на копирование. */
object Tokenizer {
    const val BOS = "<s>"
    const val EOS = "</s>"
    const val SHINGLE = 7

    private val splitter = Regex("(?<=[.!?…])\\s+|[\\r\\n]+")
    private val tokenRe = Regex(
        "\\p{N}+(?:[.,]\\p{N}+)+|[\\p{L}\\p{N}]+(?:[-’'][\\p{L}\\p{N}]+)*|[,;:]|[.!?…]"
    )

    fun isWord(t: String): Boolean = t.isNotEmpty() && t[0].isLetterOrDigit()

    fun isEnd(t: String): Boolean = t == "." || t == "!" || t == "?" || t == "…"

    /** Возвращает предложения как списки токенов (слова и знаки , ; : . ! ? …). */
    fun sentences(text: String): List<List<String>> {
        val result = ArrayList<List<String>>()
        for (part in splitter.split(text)) {
            val cleaned = ArrayList<String>()
            for (m in tokenRe.findAll(part)) {
                val t = m.value
                if (cleaned.isEmpty() && !isWord(t)) continue
                if (isEnd(t) && isEnd(cleaned.last())) continue
                cleaned.add(t)
            }
            if (cleaned.isEmpty()) continue
            val lastIdx = cleaned.size - 1
            if (!isEnd(cleaned[lastIdx])) {
                val last = cleaned[lastIdx]
                if (last == "," || last == ";" || last == ":") cleaned[lastIdx] = "." else cleaned.add(".")
            }
            val words = cleaned.count { isWord(it) }
            if (words < 3 || words > 50) continue
            val first = cleaned[0]
            val isAcronym = first.length > 1 && first.all { !it.isLetter() || it.isUpperCase() }
            if (!isAcronym) cleaned[0] = first.lowercase()
            result.add(cleaned)
        }
        return result
    }

    /** Хэш последовательности слов (FNV-1a, 64 бита). */
    fun hash(words: List<String>, from: Int = 0, to: Int = words.size): Long {
        var h = -3750763034362895579L
        for (i in from until to) {
            for (ch in words[i]) {
                h = (h xor ch.code.toLong()) * 1099511628211L
            }
            h = (h xor 32L) * 1099511628211L
        }
        return h
    }

    /** Хэши окон по SHINGLE слов; короткое предложение даёт один хэш целиком. */
    fun shingles(words: List<String>): List<Long> {
        if (words.size <= SHINGLE) return listOf(hash(words))
        val r = ArrayList<Long>()
        for (i in 0..words.size - SHINGLE) r.add(hash(words, i, i + SHINGLE))
        return r
    }
}
